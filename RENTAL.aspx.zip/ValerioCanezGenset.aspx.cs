﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace CanezPower
{
    public partial class ValerioCanezGenset : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                GridView1.DataSourceID = null;
		
                btnbuscar_Click(null,null);
            }
            
        }
        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        protected void btnbuscar_Click(object sender, EventArgs e)
        {
            try
            {
                string COMANDO = String.Format("SELECT         genset AS Genset, genset_serial AS [Genset Serial], user1 AS [End User], addressuser AS Address, engine AS Engine, engine_serial AS [Engine Serial], altenator AS Altentor, altenator_serial AS [Altenator Serial], soid_serial AS [Serial Sold], contro_panel AS [Control Panel], enclosure AS Enclosure, application1 AS Application, frequency AS Frequency, connection AS [Connection (Phase)], voltage AS Voltage, CONVERT(date,Date_Delivery) AS [Date of Delivery], CONVERT(date, Date_Commssioning )AS [Date of Commissioning],CONVERT(date, date_register) AS [Date Register], CONVERT(date,date_Mode )AS [Date Update] FROM            edgar2211.Genset_Venta where "+DROPCLIEN.Text+" like '%"+TextBox1.Text+"%'");
                    DataSet DS = CLASS_CONECTAR.CONECTAR(COMANDO);
                    if (DS.Tables[0].Rows.Count <= 0)
                    {
                        Response.Write("<script>alert('This item was not found');</script>");
                    }
                    GridView1.DataSource = DS.Tables[0];
                    GridView1.DataBind();
            }
            catch (Exception)
            {
                
                
            }
        }

        public string COMANDO = "";
        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

            COMANDO = GridView1.SelectedRow.Cells[3].Text.ToString();

            //string cmd = "NEWPLAN.aspx?id=" + COMANDO;
            //Session.Add("LK", COMANDO);

            //Server.Transfer("NEWPLAN.aspx");
            //Response.Redirect("NEWPLAN.aspx?id=" + COMANDO);
            //NEWPLAN NE = new NEWPLAN();







            //            A) Pasarlo por la querystring. 

            Response.Redirect("~/NewValerioCanez.aspx?MyVar=" + COMANDO.ToString()); 
        }
}
}