﻿using System;
using System.Collections.Generic;
using System.Data;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CanezPower
{
    public partial class NewValerioCanez : System.Web.UI.Page
    {

        public System.Security.Principal.IPrincipal User
        {
            get;
            [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Demand, ControlPrincipal = true)]
            set;
        }
        public static string user = "";
        protected String GetTime()
        {

            string name = Page.User.Identity.Name;
            ver();
            user = Page.User.Identity.Name;
            return name;
        }




        void ver()
        {

            Response.Cache.SetCacheability(HttpCacheability.Server);

            Response.Cache.SetSlidingExpiration(true);
        }




        public string SERIAL = "";

        public string model = "";
        public string site = "";
        public int palo = 1;
        public static string SIT, GEN, GENSERIAL;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                try
                {
                    //ver_NEW_site_();
                    //SERIAL = (string)(Session["LK"]);
                    SERIAL = Request.QueryString.Get("MyVar");
                    LBLESTADO.Text = SERIAL;
                    //SERIAL = Request.QueryString.Get("id");
                    //LBLESTADO.Text = (string)(Session["LK"]); ;

                    //LBLESTADO.Text = SERIAL.ToString();
                }
                catch (Exception error)
                {
                    LBLESTADO.Text = error.Message;

                }
                  
                if (string.IsNullOrEmpty(SERIAL))
            {
                BTNEDIT.Enabled = false;
                BTNDELETE.Enabled = false;

            }
            else
            {
                try
                {



                    BTNGUARDAR.Enabled = false;
                    BTNDELETE.Enabled = true;
                    BTNEDIT.Enabled = true;
                    string comando = string.Format("SELECT * FROM Genset_Venta WHERE genset_serial='" + Request.QueryString.Get("MyVar") + "'");
                    DataSet DS =  CLASS_CONECTAR.CONECTAR(comando);

                    //if (DS.Tables[0].Rows.Count > 0)
                    //{
                    txtuser.Text = DS.Tables[0].Rows[0]["user1"].ToString();
                    txtaddessuser.Text = DS.Tables[0].Rows[0]["addressuser"].ToString();
                    txtgeneration.Text = DS.Tables[0].Rows[0]["genset"].ToString();
                    txtgensetserial.Text = DS.Tables[0].Rows[0]["genset_serial"].ToString();
                    GENSERIAL = DS.Tables[0].Rows[0]["genset_serial"].ToString();

                    txtengine.Text = DS.Tables[0].Rows[0]["engine"].ToString();
                    txtengineserial.Text = DS.Tables[0].Rows[0]["engine_serial"].ToString();
                    txtaltenado.Text = DS.Tables[0].Rows[0]["altenator"].ToString();
                    txtserialaltenador.Text = DS.Tables[0].Rows[0]["altenator_serial"].ToString();
                    txtsoiddealer.Text = DS.Tables[0].Rows[0]["soid"].ToString();
                    txtserialdealer.Text = DS.Tables[0].Rows[0]["soid_serial"].ToString();
                    cbpanelcontrol.Text = DS.Tables[0].Rows[0]["contro_panel"].ToString();
                    cbenclosure.Text = DS.Tables[0].Rows[0]["enclosure"].ToString();
                    cbapplication.Text = DS.Tables[0].Rows[0]["application1"].ToString();
                    cbfrequecy.Text = DS.Tables[0].Rows[0]["frequency"].ToString();
                    cbconection.Text = DS.Tables[0].Rows[0]["connection"].ToString();
                    cbvoltage.Text = DS.Tables[0].Rows[0]["voltage"].ToString();
                    DateTime fechadelivery = Convert.ToDateTime(DS.Tables[0].Rows[0]["Date_Delivery"].ToString());
                    cbdelivery.Text = fechadelivery.ToString("yyyy-MM-dd");
                    DateTime fechacusu = Convert.ToDateTime(DS.Tables[0].Rows[0]["Date_Commssioning"].ToString());
                    txtdatecommissioning.Text = fechacusu.ToString("yyyy-MM-dd");











                }
                catch (Exception error)
                {



                    LBLESTADO.Text = error.Message;


                }

            }
           
            
            }
           



          

        }
        protected void BTNGUARDAR_Click(object sender, EventArgs e)
        {
            NEW_GENSET();
        }
        void NEW_GENSET()
        {
            try
            {

                string VALIDADR = string.Format("SELECT * FROM Genset_Venta WHERE genset_serial ='" + txtgensetserial.Text + "'");
                DataSet DS12 = CLASS_CONECTAR.CONECTAR(VALIDADR);
                if (DS12.Tables[0].Rows.Count > 0)
                {
                    LBLESTADO.Text = "A generator with this serial number already exists";
                }
                else
                {
                    SERIAL = "";


                    string COMANDO = string.Format("EXEC  NewGenset_Venta'" + txtdealer.Text + "','" + txtaddressdealer.Text + "','" + txtuser.Text + "','" + txtaddessuser.Text + "','" + txtgeneration.Text + "','" + txtgensetserial.Text + "','" + txtengine.Text + "','" + txtengineserial.Text + "','" + txtaltenado.Text + "','" + txtserialaltenador.Text + "','" + txtsoiddealer.Text + "','" + txtserialdealer.Text + "','" + cbpanelcontrol.Text + "','" + cbenclosure.Text + "','" + cbapplication.Text + "','" + cbfrequecy.Text + "','" + cbconection.Text + "','" + cbvoltage.Text + "','" + Convert.ToDateTime(cbdelivery.Text).ToString("yyyy-MM-dd") + "','" + Convert.ToDateTime(txtdatecommissioning.Text).ToString("yyyy-MM-dd") + "','" + GetTime() + "'");
                    DataSet DS = CLASS_CONECTAR.CONECTAR(COMANDO);
                    LBLESTADO.Text = "It was done correctly";
                    Response.Redirect("~/ValerioCanezGenset.aspx");
                }




            }
            catch (Exception ERROR)
            {
                LBLESTADO.Text = "ERROR EN LA OPERACION  " + ERROR.Message;

            }

        }
        protected void BTNEDIT_Click(object sender, EventArgs e)
        {
            try
            {

                if (txtgensetserial.Text == GENSERIAL)
                {

                    int id = Convert.ToInt32(Request.QueryString.Get("MyVar"));
                    string COMANDO = string.Format("EXEC  UpdateGenset_Venta  '"+id.ToString()+"','" + txtdealer.Text + "','" + txtaddressdealer.Text + "','" + txtuser.Text + "','" + txtaddessuser.Text + "','" + txtgeneration.Text + "','" + txtgensetserial.Text + "','" + txtengine.Text + "','" + txtengineserial.Text + "','" + txtaltenado.Text + "','" + txtserialaltenador.Text + "','" + txtsoiddealer.Text + "','" + txtserialdealer.Text + "','" + cbpanelcontrol.Text + "','" + cbenclosure.Text + "','" + cbapplication.Text + "','" + cbfrequecy.Text + "','" + cbconection.Text + "','" + cbvoltage.Text + "','" + Convert.ToDateTime(cbdelivery.Text).ToString("yyyy-MM-dd") + "','" + Convert.ToDateTime(txtdatecommissioning.Text).ToString("yyyy-MM-dd") + "','" + GetTime() + "'");
                    DataSet DS = CLASS_CONECTAR.CONECTAR(COMANDO);
                    LBLESTADO.Text = "It was done correctly";
                    Response.Redirect("~/ValerioCanezGenset.aspx");

                }
                else
                {
                    string VALIDADR = string.Format("SELECT * FROM Genset_Venta WHERE genset_serial ='" + txtgensetserial.Text + "'");
                    DataSet DS12 = CLASS_CONECTAR.CONECTAR(VALIDADR);
                    if (DS12.Tables[0].Rows.Count > 0)
                    {
                        LBLESTADO.Text = "A generator with this serial number already exists";
                    }
                    else
                    {
                        SERIAL = "";
                        int id = Convert.ToInt32(Request.QueryString.Get("MyVar"));

                        string COMANDO = string.Format("EXEC  UpdateGenset_Venta  '" + id.ToString() + "','" + txtdealer.Text + "','" + txtaddressdealer.Text + "','" + txtuser.Text + "','" + txtaddessuser.Text + "','" + txtgeneration.Text + "','" + txtgensetserial.Text + "','" + txtengine.Text + "','" + txtengineserial.Text + "','" + txtaltenado.Text + "','" + txtserialaltenador.Text + "','" + txtsoiddealer.Text + "','" + txtserialdealer.Text + "','" + cbpanelcontrol.Text + "','" + cbenclosure.Text + "','" + cbapplication.Text + "','" + cbfrequecy.Text + "','" + cbconection.Text + "','" + cbvoltage.Text + "','" + Convert.ToDateTime(cbdelivery.Text).ToString("yyyy-MM-dd") + "','" + Convert.ToDateTime(txtdatecommissioning.Text).ToString("yyyy-MM-dd") + "','" + GetTime() + "'");
                        DataSet DS = CLASS_CONECTAR.CONECTAR(COMANDO);
                        LBLESTADO.Text = "It was done correctly";
                        Response.Redirect("~/ValerioCanezGenset.aspx");
                    }
                }

            }
            catch (Exception)
            {
                
                
            }
        }
        protected void BTNDELETE_Click(object sender, EventArgs e)
        {
            try
            {
                string COMANDO = string.Format("DELETE FROM Genset_Venta WHERE genset_serial='" + txtgensetserial.Text + "'");
                DataSet DS = CLASS_CONECTAR.CONECTAR(COMANDO);
                LBLESTADO.Text = "SE REALIZO CORRECTAMENTE";
                SERIAL = "";
                Response.Redirect("~/ValerioCanezGenset.aspx");
            }
            catch (Exception)
            {

            }
        }
}
}